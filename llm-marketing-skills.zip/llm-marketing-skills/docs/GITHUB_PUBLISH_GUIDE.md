# GitHub Publish Guide

## 1. Create a new GitHub repository

Recommended name:

```text
llm-marketing-skills
```

Recommended description:

```text
Universal marketing skills for LLM agents: SEO, CRO, paid ads, copywriting, analytics, launch strategy, and growth.
```

Set visibility to Public if you want others to use it.

## 2. Push from your computer

```bash
cd llm-marketing-skills
git init
git add .
git commit -m "Initial universal LLM marketing skills library"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/llm-marketing-skills.git
git push -u origin main
```

## 3. Add topics

In GitHub repo settings, add topics:

```text
llm, ai-agents, agent-skills, marketing, seo, cro, paid-ads, copywriting, growth, analytics
```

## 4. Keep attribution

Because this repo is derived from an MIT-licensed project, keep:

- `LICENSE`
- `NOTICE.md`
- Attribution line in `README.md`

## 5. Enable validation

The included GitHub Action runs:

```bash
python scripts/validate_skills.py
```

It checks that every skill has a `SKILL.md`, valid frontmatter, name, description, and version metadata.
