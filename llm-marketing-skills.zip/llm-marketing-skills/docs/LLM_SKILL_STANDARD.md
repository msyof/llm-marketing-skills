# Universal LLM Skill Standard

This standard keeps skills portable across ChatGPT, Claude, Cursor, Windsurf, Codex, Gemini, and other LLM systems.

## Required folder pattern

```text
skills/{skill-slug}/SKILL.md
skills/{skill-slug}/references/ optional
skills/{skill-slug}/evals/ optional
```

## Required SKILL.md frontmatter

```yaml
---
name: skill-slug
description: "Activation rule: when this skill should be used."
metadata:
  version: 1.0.0
---
```

## Writing rules

- Keep activation logic in `description`.
- Keep the workflow in `SKILL.md`.
- Put long reference material in `references/`.
- Put test prompts or expected behavior examples in `evals/`.
- Avoid model-specific commands inside shared skill files.
- Avoid vendor-only syntax unless it is documented as an optional adapter.
- Write instructions as actionable behavior, not essays.

## Runtime behavior

When an LLM receives a user task:

1. Select the most relevant skill using `skills.json` or folder names.
2. Read `SKILL.md`.
3. Read references only when needed.
4. Apply the workflow silently.
5. Ask for missing inputs only when required.
6. Return the requested deliverable.

## Compatibility target

A skill should be useful even if the only available runtime is plain text. That means no required plugins, no hidden dependencies, and no required proprietary tool calls.
