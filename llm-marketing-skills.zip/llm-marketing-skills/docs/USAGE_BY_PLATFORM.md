# Usage by Platform

## ChatGPT Projects

1. Create a new Project.
2. Upload `skills.json`, `SKILLS_INDEX.md`, and the `skills/` folder files relevant to your work.
3. Add this Project instruction:

```text
Use the uploaded marketing skill library. For every marketing task, select the relevant skill from skills.json, read that skill's SKILL.md, and apply the workflow. Use reference files only when needed. Deliver final outputs in the user's requested format.
```

## Custom GPT

1. Add `skills.json` and selected skill folders to Knowledge.
2. Add the same instruction above to the GPT instructions.
3. Keep total file size manageable by uploading only the skills you need most often.

## Claude / Claude Code

Option A: copy skills into `.agents/skills/`.

```bash
mkdir -p .agents/skills
cp -R skills/* .agents/skills/
```

Option B: copy into `.claude/skills/` if your Claude setup expects that path.

```bash
mkdir -p .claude/skills
cp -R skills/* .claude/skills/
```

## Cursor / Windsurf

1. Copy the repo into your project as `ai-skills/` or `.agents/skills/`.
2. Reference `skills.json` from your workspace rules.
3. Ask the agent to use the specific skill folder for the task.

Example workspace rule:

```text
For marketing tasks, inspect .agents/skills or ai-skills/skills. Select and follow the relevant SKILL.md file before writing the final output.
```

## OpenAI Codex / coding agents

Keep the repo inside the workspace and point the coding agent to `skills.json`.

```text
Before changing marketing, analytics, CRO, SEO, or ad-related files, inspect skills.json and the relevant SKILL.md file.
```

## Gemini Gems / other LLMs

Upload `skills.json`, `SKILLS_INDEX.md`, and the selected `SKILL.md` files as knowledge. Use the universal instruction from the README.
