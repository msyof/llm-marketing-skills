# Notice

This repository is a universalized adaptation of the MIT-licensed `marketingskills` project by Corey Haines.

Original project metadata found in the uploaded archive:

- Project name: Marketing Skills for AI Agents
- Original author: Corey Haines
- Original license: MIT
- Original homepage/repository fields referenced: `coreyhaines31/marketingskills`

The original MIT copyright notice is preserved in `LICENSE`.

Changes in this adaptation:

- Added a platform-neutral `skills.json` manifest.
- Added universal usage docs for multiple LLM environments.
- Added GitHub publishing guide.
- Added validation script and GitHub Action.
- Added a normalized skill standard document.
- Kept original skill content, reference files, and eval files intact unless otherwise edited later by the repo owner.
