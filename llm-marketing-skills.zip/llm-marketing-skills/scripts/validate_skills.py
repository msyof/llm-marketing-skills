from pathlib import Path
import re
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "skills"
errors = []

if not SKILLS.exists():
    errors.append("Missing skills/ directory")
else:
    for folder in sorted(p for p in SKILLS.iterdir() if p.is_dir()):
        skill = folder / "SKILL.md"
        if not skill.exists():
            errors.append(f"{folder.name}: missing SKILL.md")
            continue
        text = skill.read_text(encoding="utf-8", errors="replace")
        m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
        if not m:
            errors.append(f"{folder.name}: missing YAML frontmatter")
            continue
        fm = m.group(1)
        if not re.search(r"^name:\s*.+", fm, re.M):
            errors.append(f"{folder.name}: missing name")
        if not re.search(r"^description:\s*.+", fm, re.M):
            errors.append(f"{folder.name}: missing description")
        if "version:" not in fm:
            errors.append(f"{folder.name}: missing metadata.version")

manifest = ROOT / "skills.json"
if manifest.exists():
    data = json.loads(manifest.read_text(encoding="utf-8"))
    manifest_names = {s["folder"] for s in data.get("skills", [])}
    actual_names = {p.name for p in SKILLS.iterdir() if p.is_dir()}
    if manifest_names != actual_names:
        errors.append("skills.json does not match skills/ folders")
else:
    errors.append("Missing skills.json")

if errors:
    print("Skill validation failed:")
    for e in errors:
        print(f"- {e}")
    sys.exit(1)

print("Skill validation passed.")
