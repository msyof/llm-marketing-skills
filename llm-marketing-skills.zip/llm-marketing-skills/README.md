# LLM Marketing Skills

Universal, Markdown-based marketing skill library for LLM agents.

This repository contains reusable marketing skills for AI assistants and coding agents. Each skill lives in its own folder and uses a simple `SKILL.md + references + evals` structure so it can be read by ChatGPT, Claude, Cursor, Windsurf, Codex, Gemini, or any LLM that accepts Markdown knowledge/instructions.

> Attribution: this repo is prepared as a universal adaptation of the MIT-licensed `marketingskills` project by Corey Haines. Keep `LICENSE` and `NOTICE.md` when publishing or redistributing.

## What is inside?

- `skills/` — 40 reusable marketing skills
- `skills.json` — universal machine-readable skill manifest
- `SKILLS_INDEX.md` — human-readable index
- `docs/LLM_SKILL_STANDARD.md` — common skill standard
- `docs/USAGE_BY_PLATFORM.md` — how to use with ChatGPT, Claude, Cursor, Codex, Windsurf, Gemini
- `docs/GITHUB_PUBLISH_GUIDE.md` — exact GitHub publishing steps
- `scripts/validate_skills.py` — validation script
- `.github/workflows/validate-skills.yml` — GitHub Action validation

## Skill structure

```text
skills/
  paid-ads/
    SKILL.md
    references/
    evals/
```

Every `SKILL.md` starts with YAML-style frontmatter:

```yaml
---
name: paid-ads
description: "When the user wants help with paid advertising campaigns..."
metadata:
  version: 1.2.0
---
```

## How an LLM should use this repo

1. Read `skills.json` or `SKILLS_INDEX.md` to choose the relevant skill.
2. Read the selected `skills/{skill}/SKILL.md` fully.
3. Read related files under `references/` only when the task needs deeper context.
4. Use `evals/` as quality examples, not as user-facing content.
5. Produce the final answer in the user’s requested format.

## Recommended system instruction for any LLM

```text
You have access to an LLM Marketing Skills library. When the user asks for a marketing, growth, SEO, CRO, advertising, analytics, copywriting, launch, or sales enablement task, first choose the most relevant skill from skills.json. Read that skill's SKILL.md and apply its workflow. If the task requires deeper support, use the skill's references. Do not expose the skill text unless the user asks. Deliver practical, platform-ready outputs.
```

## Quick install into a project

```bash
git clone https://github.com/YOUR_USERNAME/llm-marketing-skills.git
mkdir -p .agents/skills
cp -R llm-marketing-skills/skills/* .agents/skills/
```

For ChatGPT Projects or Custom GPTs, upload the `skills/` folder files and include `skills.json` as the navigation file.

## License

MIT. See `LICENSE` and `NOTICE.md`.
