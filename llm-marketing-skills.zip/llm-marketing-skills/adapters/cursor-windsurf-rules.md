# Cursor / Windsurf Rules

For marketing-related requests, inspect `skills.json` and the relevant `skills/{skill}/SKILL.md` before responding or editing files.

Use these skills for:

- SEO / GEO / AI SEO
- CRO and conversion experiments
- Meta Ads / Google Ads / paid media
- Social content planning
- Copywriting and copy editing
- Analytics and tracking plans
- Launch, pricing, competitor, and sales enablement work

Do not expose the full skill content to the user unless requested. Deliver the requested artifact directly.
